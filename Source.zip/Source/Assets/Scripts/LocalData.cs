﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LocalData 
{
    public static List<int> activeWeaopnList = new List<int>() { 0};
    public static int? playercurHP=null;
    public static int? playerAddHpProp = null;
}
