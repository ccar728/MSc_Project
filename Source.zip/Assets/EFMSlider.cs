﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class EFMSlider : MonoBehaviour
{
    Slider slider;
    private void Awake()
    {
        slider = GetComponent<Slider>();
    }
    // Start is called before the first frame update
    void Start()
    {
        slider.value = MusicController.Instance.effectVolume;
        slider.onValueChanged.AddListener((float value) =>
        {
            MusicController.Instance.effectVolume = slider.value;
        });
    }
}
