﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class BGMSlider : MonoBehaviour
{
    Slider slider;
    private void Awake()
    {
        slider = GetComponent<Slider>();
    }
    // Start is called before the first frame update
    void Start()
    {
        slider.value = MusicController.Instance.BgVolume;
        slider.onValueChanged.AddListener((float value)=> 
        {
            MusicController.Instance.BgVolume = slider.value;
        });
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
